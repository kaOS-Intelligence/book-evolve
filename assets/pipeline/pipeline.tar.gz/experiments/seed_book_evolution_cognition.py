#!/usr/bin/env python3
"""Seed the book-evolution cognition store with a dictation transcript and
author reference (style) samples.

Uses the engine's own ``Cognition`` class, so the on-disk format (cognition.json
+ FAISS index + id mappings) is always exactly what the pipeline expects —
the store is written and read by the same code.

Embeddings come from Ollama via the engine's EmbeddingService
(OLLAMA_BASE_URL / OLLAMA_EMBED_MODEL, default bge-m3 at 127.0.0.1:11434).
If Ollama is unreachable, seeding degrades to a keyword-only store: items are
written without vectors and semantic retrieval falls back gracefully.

Usage:
  python3 seed_book_evolution_cognition.py \\
    --dictation /path/to/chapter-transcript.txt \\
    --reference /path/to/author-sample.txt "Book Title" \\
    [--reference ...] \\
    [--output-dir ./cognition_data]
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path

EXPERIMENTS_DIR = Path(__file__).resolve().parent
EVOLVE_ROOT = EXPERIMENTS_DIR.parent


def _bootstrap_evolve():
    """Load the pipeline package the same way run_book_evolution.py does."""
    package_name = "Evolve"
    if package_name not in sys.modules:
        spec = importlib.util.spec_from_file_location(
            package_name,
            EVOLVE_ROOT / "__init__.py",
            submodule_search_locations=[str(EVOLVE_ROOT)],
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules[package_name] = module
        spec.loader.exec_module(module)


def _write_keyword_only_store(
    output_dir: Path, dictation_text: str, reference_items: list[dict]
) -> None:
    """Fallback store when embeddings are unavailable.

    Same items/str_to_int/int_to_str shape Cognition persists, minus the
    FAISS index — retrieval degrades to no semantic hits, and the evaluator
    still finds the dictation and style samples by topic.
    """
    import uuid

    items: dict[str, dict] = {}
    str_to_int: dict[str, int] = {}
    int_to_str: dict[str, str] = {}

    def _add(content: str, metadata: dict) -> None:
        item_id = str(uuid.uuid4())
        int_id = len(str_to_int)
        items[item_id] = {
            "id": item_id,
            "content": content,
            "source": metadata.get("source", ""),
            "metadata": metadata,
        }
        str_to_int[item_id] = int_id
        int_to_str[str(int_id)] = item_id

    _add(
        dictation_text,
        {"topic": "dictation_transcript", "source_type": "dictation"},
    )
    for ref in reference_items:
        _add(
            ref["text"],
            {
                "topic": "author_style_sample",
                "source_type": "reference_book",
                "source": ref["source"],
                "file_path": ref["path"],
            },
        )

    data = {
        "items": items,
        "str_to_int": str_to_int,
        "int_to_str": int_to_str,
        "next_int_id": len(str_to_int),
    }
    (output_dir / "cognition.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        f"Keyword-only cognition store written ({len(items)} items, no embeddings)."
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Seed the book-evolution cognition store"
    )
    parser.add_argument(
        "--dictation", required=True, help="Path to dictation transcript text file"
    )
    parser.add_argument(
        "--reference", action="append",
        nargs=2, metavar=("PATH", "SOURCE"),
        dest="references",
        help=(
            "Path to author book sample and its source title (repeatable). "
            "Optional — without references the council evolves on dictation "
            "alone and style matching is weaker."
        ),
    )
    parser.add_argument(
        "--output-dir", default="./cognition_data",
        help="Output directory (default: ./cognition_data)"
    )
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    dictation_path = Path(args.dictation)
    if not dictation_path.is_file():
        raise SystemExit(f"Dictation file not found: {dictation_path}")
    dictation_text = dictation_path.read_text(encoding="utf-8")

    reference_items: list[dict] = []
    for ref_path_str, source in (args.references or []):
        ref_path = Path(ref_path_str)
        if not ref_path.is_file():
            raise SystemExit(f"Reference file not found: {ref_path}")
        reference_items.append(
            {
                "path": ref_path_str,
                "source": source,
                "text": ref_path.read_text(encoding="utf-8"),
            }
        )

    if not reference_items:
        print(
            "Warning: no --reference samples provided. Style matching will be "
            "weaker; the council will evolve on dictation alone.",
            file=sys.stderr,
        )

    _bootstrap_evolve()
    from Evolve.utils.structures import CognitionItem  # noqa: E402

    try:
        from Evolve.cognition import Cognition  # noqa: E402

        cognition = Cognition(
            storage_dir=output_dir,
            embedding_model="bge-m3-local",
            embedding_dim=1024,
            retrieval_top_k=10,
            score_threshold=0.3,
            faiss_index_type="IP",
        )
    except Exception as e:  # Ollama down / faiss missing — degrade gracefully
        print(
            f"Warning: embedding service unavailable ({e}).",
            file=sys.stderr,
        )
        print(
            "Continuing without embeddings (retrieval will use keyword match).",
            file=sys.stderr,
        )
        _write_keyword_only_store(output_dir, dictation_text, reference_items)
        return 0

    # Fresh store per seed — the service re-seeds per chapter.
    cognition.reset()

    cognition.add(
        CognitionItem(
            content=dictation_text,
            source=str(dictation_path),
            metadata={
                "topic": "dictation_transcript",
                "source_type": "dictation",
            },
        )
    )

    for ref in reference_items:
        cognition.add(
            CognitionItem(
                content=ref["text"],
                source=ref["source"],
                metadata={
                    "topic": "author_style_sample",
                    "source_type": "reference_book",
                    "source": ref["source"],
                    "file_path": ref["path"],
                },
            )
        )

    print(
        f"Cognition store written: {output_dir / 'cognition.json'} "
        f"({len(cognition)} items, FAISS index: {cognition.faiss.size} vectors)"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
