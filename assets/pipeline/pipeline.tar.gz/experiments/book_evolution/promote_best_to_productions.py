#!/usr/bin/env python3
"""Promote the best Book Evolution candidate into the sovereign files corpus.

Chapter-aware and merge-safe:

  * The chapter being promoted is chosen by ``BOOK_EVOLUTION_CHAPTER_N`` (default 1).
  * The best candidate is resolved from ``steps/best/*`` (highest-scoring snapshot).
  * Every chapter lands in ONE folder under ``files/{contentId}__{book-title}``.
    The chapter MDX for chapter N is written, then ``toc.json`` is rebuilt by
    *upserting* this chapter's entry into whatever is already on disk, and
    ``index.mdx`` is regenerated from the merged TOC.
"""

from __future__ import annotations

import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

EXP_DIR = Path(__file__).resolve().parent
STEPS_DIR = Path(
    os.environ.get("BOOK_EVOLUTION_STEPS_DIR", str(EXP_DIR / "steps"))
)


def corpus_root() -> Path:
    """Resolve where promoted chapters are written.

    Defaults to <project>/output. Override with BOOK_EVOLUTION_OUTPUT_ROOT.
    """
    env = os.environ.get('BOOK_EVOLUTION_OUTPUT_ROOT', '').strip()
    if env:
        return Path(env).expanduser()
    repo = EXP_DIR.parents[2]
    return repo / 'output'



# Override these per project.
BOOK_TITLE = os.environ.get("BOOK_EVOLUTION_TITLE", "Untitled Evolved Book")

def _default_content_id() -> str:
    """Stable content id derived from the book title.

    The same title always maps to the same folder, so multi-chapter runs
    merge into one book without any configuration. Set
    BOOK_EVOLUTION_CONTENT_ID to override.
    """
    import uuid

    return str(
        uuid.uuid5(uuid.NAMESPACE_URL, f"book-evolve://{BOOK_TITLE.lower()}")
    )


CONTENT_ID = (
    os.environ.get("BOOK_EVOLUTION_CONTENT_ID", "").strip()
    or _default_content_id()
)
BOOK_AUTHOR = os.environ.get("BOOK_EVOLUTION_AUTHOR", "Unknown Author")
BOOK_SUBTITLE = os.environ.get(
    "BOOK_EVOLUTION_SUBTITLE",
    "Evolved from dictation in the author's own voice.",
)

_ROMAN = [(10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]


def _slugify(text: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return s


def roman(n: int) -> str:
    out = []
    for value, sym in _ROMAN:
        while n >= value:
            out.append(sym)
            n -= value
    return "".join(out) or "I"


def chapter_n() -> int:
    try:
        return int(os.environ.get("BOOK_EVOLUTION_CHAPTER_N", "1"))
    except ValueError:
        return 1


def extract_body_title(body: str) -> tuple[str | None, str]:
    """Pull the model's own chapter heading off the top of the body.

    The council usually opens its candidate with '# Chapter N: Some Title'.
    Shipping that verbatim under the injected '## <filename title>' produced
    duplicated, inverted headings in every chapter. Instead: lift the
    heading, strip chapter-number prefixes, and let it BE the chapter title
    (frontmatter, toc, and the single rendered heading), falling back to the
    filename-derived title when the heading carries no real text.

    Returns (title_or_None, body_without_that_heading).
    """
    m = re.match(r"\s*#{1,3}\s+(.+?)\s*\n", body)
    if not m:
        return None, body
    rest = body[m.end():].lstrip("\n")
    t = m.group(1).strip().strip("#").strip()
    t = re.sub(r"(?i)^chapter\s+[\w-]+\s*[:.\-—]?\s*", "", t)
    t = re.sub(r"^\d+\s*[.:)\-—]\s*", "", t)
    # Spelled-out chapter numbers used as a prefix: "Seventeen: Title"
    number_word = (
        r"(?:twenty|thirty|forty)?-?"
        r"(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|"
        r"thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|"
        r"twenty|thirty|forty)"
    )
    t = re.sub(rf"(?i)^{number_word}\s*[:.\-—]\s*", "", t)
    t = t.strip()
    return (t or None), rest


def section_headings(body: str) -> list[str]:
    """All '## ' section headings in the body, in order."""
    return [
        m.group(1).strip()
        for m in re.finditer(r"^##\s+(.+?)\s*$", body, re.MULTILINE)
    ]


def _anchor(text: str) -> str:
    return _slugify(text)


_FOLDER_NAME = f"{CONTENT_ID}__{_slugify(BOOK_TITLE)}" if CONTENT_ID else f"evolved__{_slugify(BOOK_TITLE)}"


def out_root() -> Path:
    # Standalone projects (npx book-evolve) set BOOK_EVOLUTION_OUTPUT_DIR to
    # write directly to the project's output/ folder. Sovereign runs leave it
    # unset and land in the sovereign files corpus.
    direct = os.environ.get("BOOK_EVOLUTION_OUTPUT_DIR", "").strip()
    if direct:
        return Path(direct).expanduser()
    return corpus_root() / "files" / _FOLDER_NAME


def _score_of(results: dict) -> float:
    for key in ("score", "eval_score", "combined_score"):
        try:
            return float(results[key])
        except (KeyError, TypeError, ValueError):
            continue
    return 0.0


def resolve_best() -> tuple[str, float]:
    best_text: str | None = None
    best_score = float("-inf")

    best_root = STEPS_DIR / "best"
    if best_root.is_dir():
        for step_dir in sorted(best_root.iterdir()):
            code = step_dir / "code"
            results = step_dir / "results.json"
            if not code.is_file():
                continue
            score = 0.0
            if results.is_file():
                try:
                    score = _score_of(
                        json.loads(results.read_text(encoding="utf-8"))
                    )
                except json.JSONDecodeError:
                    score = 0.0
            if score > best_score:
                best_score = score
                best_text = code.read_text(encoding="utf-8")

    if best_text is None and STEPS_DIR.is_dir():
        for step_dir in sorted(STEPS_DIR.iterdir()):
            if step_dir.name == "best":
                continue
            code = step_dir / "candidate.py"
            results = step_dir / "eval_result.json"
            if not code.is_file():
                continue
            score = 0.0
            if results.is_file():
                try:
                    score = _score_of(
                        json.loads(results.read_text(encoding="utf-8"))
                    )
                except json.JSONDecodeError:
                    score = 0.0
            if score > best_score:
                best_score = score
                best_text = code.read_text(encoding="utf-8")

    if best_text is None:
        raise SystemExit(f"No best candidate found under {STEPS_DIR}")
    return best_text, (best_score if best_score != float("-inf") else 0.0)


def _esc(text: str) -> str:
    return text.replace("\\", "\\\\").replace('"', '\\"')


def _paragraphs(text: str) -> list[str]:
    """Split the body into render blocks, preserving structure.

    Plain prose paragraphs are reflowed onto one line. Everything whose
    line structure IS its meaning ships verbatim: fenced code blocks,
    blockquotes/verse (lines starting with '>'), markdown lists, tables,
    headings, and <ai-script> trailers. Reflowing those (the v1.2.0
    behavior) destroyed epigraph lineation and made setup-guide command
    blocks unusable.
    """
    blocks: list[str] = []
    verbatim: list[str] = []
    prose: list[str] = []
    in_fence = False
    in_script = False

    def flush_prose() -> None:
        if prose:
            blocks.append(" ".join(prose))
            prose.clear()

    def flush_verbatim() -> None:
        if verbatim:
            blocks.append("\n".join(verbatim).rstrip())
            verbatim.clear()

    structural = re.compile(r"^(\s*>|#{1,6}\s|\s*([-*+]|\d+[.)])\s|\s*\|)")

    for line in text.strip().splitlines():
        stripped = line.strip()
        if in_fence or in_script:
            verbatim.append(line)
            if in_fence and stripped.startswith("```"):
                in_fence = False
            if in_script and stripped.startswith("</ai-script>"):
                in_script = False
            if not in_fence and not in_script:
                flush_verbatim()
            continue
        if stripped.startswith("```") or stripped.startswith("<ai-script"):
            flush_prose()
            verbatim.append(line)
            in_fence = stripped.startswith("```") and stripped.count("```") == 1
            in_script = stripped.startswith("<ai-script") and "</ai-script>" not in stripped
            if not in_fence and not in_script:
                flush_verbatim()
            continue
        if not stripped:
            flush_prose()
            flush_verbatim()
            continue
        if structural.match(line):
            flush_prose()
            verbatim.append(line)
            continue
        flush_verbatim()
        prose.append(stripped)

    flush_prose()
    flush_verbatim()
    return blocks


def cover_toc_entry() -> dict:
    return {
        "chapterId": "00",
        "position": -1,
        "title": BOOK_TITLE,
        "slug": "00-cover",
        "wordCount": 0,
        "readingTimeMinutes": 0,
        "headings": [],
        "chapterClass": "frontmatter",
        "epubType": "cover",
        "structureSlot": "cover",
    }


def build_cover_mdx() -> str:
    return f"""---
chapterId: "00"
title: "{_esc(BOOK_TITLE)}"
slug: "00-cover"
position: -1
wordCount: 0
readingTimeMinutes: 0
chapterClass: "frontmatter"
structureSlot: "cover"
epubType: "cover"
headings: []
---

# {_esc(BOOK_TITLE)}

By {_esc(BOOK_AUTHOR)}
"""


def build_chapter_mdx(
    body: str, *, meta: dict, score: float
) -> str:
    paras = _paragraphs(body)
    if not paras:
        raise SystemExit("best candidate is empty")

    title = meta["title"]
    slug = meta["slug"]
    anchor = meta["anchor"]
    word_count = meta["wordCount"]
    reading_min = meta["readingTimeMinutes"]
    chapter_id = meta["chapterId"]
    hash_tag = (
        f"evolved-chapter-{meta['chapter']}-score-{score:.4f}".replace(
            ".", "-"
        )
    )

    lines = [
        "---",
        f'chapterId: "{chapter_id}"',
        f'title: "{_esc(title)}"',
        f'slug: "{slug}"',
        f"wordCount: {word_count}",
        f"readingTimeMinutes: {reading_min}",
        f"position: {meta['position']}",
        f'parentContentId: "{CONTENT_ID}"',
        'chapterClass: "bodymatter"',
        'structureSlot: "body"',
        'startSide: "recto"',
        'epubType: "bodymatter z3998:fiction"',
        f'authorBio: "{_esc(BOOK_AUTHOR)}"',
        "headings:",
        f"  - level: 2",
        f'    text: "{_esc(title)}"',
        f'    anchor: "{anchor}"',
        f'    epubType: "bodymatter z3998:fiction"',
        *[
            line
            for section in meta.get("sections", [])
            for line in (
                f"  - level: 2",
                f'    text: "{_esc(section)}"',
                f'    anchor: "{_anchor(section)}"',
                f'    epubType: "bodymatter z3998:fiction"',
            )
        ],
        f'sourceFileHash: "{hash_tag}"',
        "---",
        "",
        f"## {_esc(title)}",
    ]

    for para in paras:
        lines.extend(["", para])

    return "\n".join(lines).rstrip() + "\n"


def _toc_entry(meta: dict) -> dict:
    headings = [
        {
            "level": 2,
            "text": meta["title"],
            "anchor": meta["anchor"],
            "epubType": "bodymatter z3998:fiction",
        }
    ]
    for section in meta.get("sections", []):
        headings.append(
            {
                "level": 2,
                "text": section,
                "anchor": _anchor(section),
                "epubType": "bodymatter z3998:fiction",
            }
        )
    return {
        "chapterId": meta["chapterId"],
        "position": meta["position"],
        "title": meta["title"],
        "slug": meta["slug"],
        "wordCount": meta["wordCount"],
        "readingTimeMinutes": meta["readingTimeMinutes"],
        "headings": headings,
        "chapterClass": "bodymatter",
        "epubType": "bodymatter z3998:fiction",
        "structureSlot": "body",
    }


def load_existing_toc(path: Path) -> list[dict]:
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except json.JSONDecodeError:
        return []


def _resolve_title_collision(
    title: str, *, self_chapter_id: str, toc_path: Path
) -> str:
    """Last-resort backstop: never let two chapters ship the same title.

    Compares case-insensitively against every other chapter's title in toc.json
    (ignoring the chapter being promoted, matched by chapterId). On collision,
    appends the chapter number as a disambiguator and warns. The prompt-level
    rule and service-layer used-titles injection are the primary defenses; this
    guarantees no duplicate can ever silently ship.
    """
    if not title or not toc_path.is_file():
        return title
    try:
        existing = json.loads(toc_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return title
    if not isinstance(existing, list):
        return title
    norm = re.sub(r"[^a-z0-9]+", " ", title.lower()).strip()
    for e in existing:
        if not isinstance(e, dict):
            continue
        if str(e.get("chapterId")) == str(self_chapter_id):
            continue  # this is us, upserting
        other = e.get("title", "")
        other_norm = re.sub(r"[^a-z0-9]+", " ", str(other).lower()).strip()
        if other_norm and other_norm == norm:
            print(
                f"  WARNING: title collision '{title}' matches chapter "
                f"{e.get('chapterId')}; disambiguating.",
                file=sys.stderr,
            )
            return f"{title} (Ch. {self_chapter_id})"
    return title


def merge_toc(existing: list[dict], entry: dict) -> list[dict]:
    by_id: dict[str, dict] = {}
    for e in existing:
        if not isinstance(e, dict):
            continue
        if e.get("slug") == "00-cover" or e.get("chapterId") == "00":
            continue
        by_id[str(e.get("chapterId"))] = e
    by_id[str(entry["chapterId"])] = entry
    body = list(by_id.values())
    body.sort(
        key=lambda e: (
            int(e.get("position", 0) or 0),
            str(e.get("chapterId")),
        )
    )
    return [cover_toc_entry(), *body]


def _index_toc_object(e: dict) -> str:
    title = json.dumps(e.get("title", ""), ensure_ascii=False)
    slug = e.get("slug", "")
    wc = int(e.get("wordCount", 0) or 0)
    cid = e.get("chapterId", "")
    rt = int(e.get("readingTimeMinutes", 0) or 0)
    chapter_class = e.get("chapterClass", "bodymatter")
    structure_slot = e.get("structureSlot", "body")
    epub_type = e.get("epubType", "chapter")
    return (
        f"    {{ title: {title}, slug: \"{slug}\", wordCount: {wc}, "
        f'chapterId: "{cid}", readingTimeMinutes: {rt}, '
        f'chapterClass: "{chapter_class}", structureSlot: '
        f'"{structure_slot}", epubType: "{epub_type}" }}'
    )


def build_index_mdx(toc: list[dict], *, score: float) -> str:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    body_entries = [e for e in toc if e.get("slug") != "00-cover"]
    total_words = sum(
        int(e.get("wordCount", 0) or 0) for e in body_entries
    )
    chapter_count = len(body_entries)

    chapters_block = ",\n".join(_index_toc_object(e) for e in toc)
    span = (
        f"Chapter {body_entries[0].get('chapterId')}"
        if chapter_count == 1
        else (
            f"Chapters {body_entries[0].get('chapterId')}–"
            f"{body_entries[-1].get('chapterId')}"
        )
    )

    return f"""---
contentId: "{CONTENT_ID}"
kind: evolved_book
title: "{_esc(BOOK_TITLE)}"
description: "{_esc(BOOK_SUBTITLE)}"
sourceFormat: dictation-evolved
producedBy: "Book Evolution Pipeline"
sourceLanguage: en
targetLanguage: en
authorBio: "{_esc(BOOK_AUTHOR)}"
publisher: Consilience Press
language: en
evalScore: {score:.4f}
convertedAt: "{now}"
wordCount: {total_words}
chapterCount: {chapter_count}
chapterSpan: "{span}"
chapterClassSummary:
  frontmatter: 1
  bodymatter: {chapter_count}
tocSlug: toc.json
subjects:
  - Evolved Book
  - Dictation-to-Prose
---

<IndexTOC
  chapters={{[
{chapters_block}
  ]}}
/>
"""


def main() -> int:
    n = chapter_n()
    body, score = resolve_best()

    fallback_title = os.environ.get("BOOK_EVOLUTION_CHAPTER_TITLE", f"Chapter {n}")
    body_title, body = extract_body_title(body)
    title = body_title or fallback_title
    nn = f"{n:02d}"
    # Cross-chapter title uniqueness backstop. The primary defenses are the
    # researcher prompt rule and the service-layer used-titles injection; this
    # guarantees no duplicate can ever silently land in toc.json.
    title = _resolve_title_collision(
        title, self_chapter_id=nn, toc_path=out_root() / "toc.json"
    )
    # Slug stays filename-stable (fallback title) so re-promotions upsert the
    # same file even when the model retitles the chapter.
    slug = (
        f"{nn}-{_slugify(fallback_title)}"
        if fallback_title != f"Chapter {n}"
        else f"{nn}-chapter-{n}"
    )
    anchor = f"chapter-{n}"
    word_count = len(re.findall(r"\w+", body))
    reading_min = max(1, round(word_count / 220))

    meta = {
        "chapter": n,
        "title": title,
        "slug": slug,
        "anchor": anchor,
        "chapterId": nn,
        "position": n,
        "wordCount": word_count,
        "readingTimeMinutes": reading_min,
        "sections": section_headings(body),
    }

    root = out_root()
    chapters_dir = root / "chapters"
    chapters_dir.mkdir(parents=True, exist_ok=True)

    chapter_mdx = build_chapter_mdx(body, meta=meta, score=score)
    chapter_path = chapters_dir / f"{slug}.mdx"
    chapter_path.write_text(chapter_mdx, encoding="utf-8")

    cover_path = chapters_dir / "00-cover.mdx"
    if not cover_path.exists():
        cover_path.write_text(build_cover_mdx(), encoding="utf-8")

    toc = merge_toc(
        load_existing_toc(root / "toc.json"), _toc_entry(meta)
    )
    (root / "toc.json").write_text(
        json.dumps(toc, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (root / "index.mdx").write_text(
        build_index_mdx(toc, score=score), encoding="utf-8"
    )

    print(f"Promoted Chapter {n} -> {root}")
    print(
        f"  chapters/{slug}.mdx ({word_count} words, score={score:.4f})"
    )
    print(
        f"  toc.json now has {len(toc)} chapter(s); index.mdx regenerated"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
