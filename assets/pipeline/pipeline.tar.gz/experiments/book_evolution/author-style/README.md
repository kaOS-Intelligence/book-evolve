Place samples of your published writing here as .txt files.
These anchor the council to your voice. More is better; 2-3 chapters
of a previous book works well.
