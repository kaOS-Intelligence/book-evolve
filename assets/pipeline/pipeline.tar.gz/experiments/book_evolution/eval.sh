#!/bin/bash
# Book Evolution — evaluator shell wrapper.
# Invoked by the ASI-Evolve pipeline per the evaluator contract:
#   eval.sh <program_path> <output_json_path>

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$SCRIPT_DIR/evaluator.py" "$1" "$2"
