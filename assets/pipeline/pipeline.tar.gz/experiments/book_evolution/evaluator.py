"""
Book Evolution — LLM-Judge Evaluator
======================================
Called by eval.sh per the ASI-Evolve evaluator contract:
  python3 evaluator.py <program_path> <output_json_path>

The "program" is a candidate evolved chapter (plain text). The evaluator
scores it on six axes by calling the LiteLLM proxy with a structured
rubric. Output is a JSON file with at minimum { "score": <float> }.

Requires the LiteLLM proxy running at 127.0.0.1:4000 and the cognition
store at cognition_data/cognition.json for style-sample retrieval.
"""

from __future__ import annotations

import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any

# Judge-robustness knobs.
JUDGE_ATTEMPTS = 3
JUDGE_RETRY_BACKOFF_S = 4.0


# ── LiteLLM call ──────────────────────────────────────────────────────────


def judge_model() -> str:
    """Judge model: JUDGE_MODEL env, else the default proxy route."""
    return os.environ.get("JUDGE_MODEL", "").strip() or "deepseek-v4-pro-cloud"


def _api_base() -> str:
    return (
        os.environ.get("LITELLM_BASE_URL", "").strip()
        or "http://127.0.0.1:4000/v1"
    ).rstrip("/")


def _api_key() -> str:
    """LITELLM_API_KEY, else ~/.litellm-master-key, else "EMPTY"."""
    env_key = os.environ.get("LITELLM_API_KEY", "").strip()
    if env_key:
        return env_key
    key_file = os.path.expanduser("~/.litellm-master-key")
    if os.path.exists(key_file):
        try:
            key = open(key_file, "r", encoding="utf-8").read().strip()
            if key:
                return key
        except OSError:
            pass
    return "EMPTY"


def call_llm(prompt: str, model: str | None = None, max_tokens: int = 8192) -> str:
    """Call the configured OpenAI-compatible endpoint for a completion."""
    import urllib.request
    import urllib.error

    url = _api_base() + "/chat/completions"
    body = json.dumps(
        {
            "model": model or judge_model(),
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": 0.3,
        }
    ).encode("utf-8")

    api_key = _api_key()

    req = urllib.request.Request(
        url,
        data=body,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
    )

    try:
        with urllib.request.urlopen(req, timeout=300) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data["choices"][0]["message"]["content"]
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8")[:500]
        except Exception:
            pass
        print(
            f"LLM HTTP {e.code} calling {e.url}: {body}",
            file=sys.stderr,
        )
        return ""
    except Exception as e:
        print(
            f"LLM call failed: {type(e).__name__}: {e}",
            file=sys.stderr,
        )
        return ""


# ── Style sample retrieval from cognition store ───────────────────────────


def load_style_samples(script_dir: Path) -> list[dict] | None:
    """Load author reference book samples from the cognition store."""
    cognition_path = script_dir / "cognition_data" / "cognition.json"
    if not cognition_path.exists():
        return None

    with open(cognition_path) as f:
        data = json.load(f)

    samples: list[dict] = []
    for item in data.get("items", {}).values():
        meta = item.get("metadata", {})
        if meta.get("topic") == "author_style_sample":
            samples.append(
                {
                    "content": item.get("content", ""),
                    "source": meta.get("source", "Unknown"),
                }
            )

    return samples if samples else None


def load_dictation(script_dir: Path) -> str | None:
    """Load the dictation transcript from the cognition store."""
    cognition_path = script_dir / "cognition_data" / "cognition.json"
    if not cognition_path.exists():
        return None

    with open(cognition_path) as f:
        data = json.load(f)

    for item in data.get("items", {}).values():
        meta = item.get("metadata", {})
        if meta.get("topic") == "dictation_transcript":
            return item.get("content", "")

    return None


# ── Scoring rubric ────────────────────────────────────────────────────────


def build_eval_prompt(
    candidate: str,
    style_samples: list[dict] | None,
    dictation: str | None,
    *,
    chapter_n: int = 1,
) -> str:
    """Build the evaluation prompt for the LLM judge."""

    style_block = ""
    if style_samples:
        style_block = "## Author Reference Samples (Style Anchor)\n\n"
        for i, sample in enumerate(style_samples[:3]):
            style_block += f'### Sample {i + 1} — From "{sample["source"]}"\n'
            style_block += f"{sample['content'][:2000]}\n\n"

    dictation_block = ""
    if dictation:
        dictation_block = f"""
## Original Dictation Transcript (Content Anchor)

{dictation[:12000]}

"""

    return f"""You are a literary judge evaluating a candidate evolved book chapter.
This chapter was evolved from a raw dictated transcript. The author's reference
book samples are provided as the style anchor; the dictation is the content anchor.

{dictation_block}
{style_block}
The candidate evolved chapter:

{candidate[:16000]}

Score this evolved chapter on SIX axes, each 0.0-1.0. Be rigorous but fair.
The goal is EVOLUTION — the candidate must re-express the dictation in the
author's voice, not transcribe it. A near-verbatim copy of the dictation is a
failure regardless of how clean the prose reads.

1. CONTENT FIDELITY (weight 0.25): How faithfully does this preserve the dictation?
   - Every factual claim, scene, character, and narrative beat preserved
   - No invented events, characters, or details
   - Named persons, places, dates, and events match the dictation
   - No significant omissions
   - CRITICAL: silently dropping a beat to avoid rewriting a banned construction
     (e.g. deleting a "not X, but Y" sentence) is a fidelity FAILURE, not a
     success. Banned constructions must be REWRITTEN as declaratives that keep
     the content — never deleted. Penalize amputated chapters heavily.

2. AUTHOR STYLE MATCH (weight 0.25): Does this read like the author wrote it?
   - Sentence architecture matches reference samples (terse vs expansive)
   - Vocabulary register matches (formal, colloquial, poetic, technical)
   - Paragraph rhythm and transitions match
   - Dialogue handling matches (tagged, untagged, embedded, reported)
   - Descriptive density matches (spare and cinematic, or lush and immersive)
   - No banned "negation-antithesis" constructions ("not X, but Y", "less a…
     than a", "not so much… as"). These are forbidden by the voice canon.

3. EVOLUTIONARY NOVELTY (weight 0.15): Has the dictation actually been re-expressed,
   or merely transcribed with light edits? Compare sentence-by-sentence against the
   dictation transcript above.
   - 0.0-0.2: near-verbatim copy. The dictation's sentences survive almost
     word-for-word, with only punctuation, light word swaps, or one degraded
     sentence. This is transcription, not evolution.
   - 0.3-0.5: partial evolution. Some beats are re-expressed in the author's
     voice; others are lifted largely intact.
   - 0.6-1.0: genuine evolution. The content is fully preserved but every beat
     is rebuilt in the author's own sentence architecture and vocabulary — the
     dictation is a source, not a scaffold.
   - A chapter that "faithfully reproduces the dictation" is, by definition,
     scoring near 0.0 on this axis.

4. LITERARY QUALITY (weight 0.15): Is this beautiful, powerful prose?
   - Rhythm and cadence on the page
   - Vivid imagery that serves the narrative
   - Varied sentence length for pacing
   - Natural flow — no awkward constructions or filler

5. STRUCTURAL COHERENCE (weight 0.10): Does this chapter hold together?
   - Clear beginning that hooks, middle that develops, end that lands
   - Smooth transitions between scenes and ideas
   - No abrupt jumps or unfinished threads

6. READABILITY (weight 0.10): Is this clear and engaging?
   - Accessible to the intended audience
   - No unnecessary jargon or opacity
   - Reader drawn forward, not struggling

Return ONLY a JSON object with this exact structure, nothing else:
{{"content_fidelity": <0.0-1.0>, "author_style_match": <0.0-1.0>, "evolutionary_novelty": <0.0-1.0>, "literary_quality": <0.0-1.0>, "structural_coherence": <0.0-1.0>, "readability": <0.0-1.0>, "analysis": "<one sentence summary of strengths and weaknesses>"}}
"""


def parse_judge_response(response: str) -> dict[str, Any]:
    """Parse the LLM judge's JSON response."""
    json_match = re.search(r"\{.*\}", response, re.DOTALL)
    if not json_match:
        return {"error": "no_json_found", "raw": response[:200]}

    try:
        parsed = json.loads(json_match.group(0))
        return parsed
    except json.JSONDecodeError:
        return {"error": "json_parse_failed", "raw": response[:200]}


def compute_score(axes: dict[str, Any]) -> float:
    """Compute weighted score from the six axes.

    Weights sum to 1.00. Novelty was added (and fidelity/style reduced from
    0.30 -> 0.25) because the old rubric rewarded verbatim copying under the
    guise of "fidelity" — a 96% word-identical candidate once scored 0.975.
    """
    weights = {
        "content_fidelity": 0.25,
        "author_style_match": 0.25,
        "evolutionary_novelty": 0.15,
        "literary_quality": 0.15,
        "structural_coherence": 0.10,
        "readability": 0.10,
    }
    score = 0.0
    for axis, weight in weights.items():
        val = axes.get(axis, 0.0)
        try:
            score += float(val) * weight
        except (TypeError, ValueError):
            pass
    return round(score, 4)


# ── Near-copy detection (deterministic backstop) ─────────────────────────
#
# The LLM judge cannot reliably tell when a candidate is a near-verbatim copy
# of the dictation — in the Free and Safe run, chapter 38 was 96% word-
# identical to its dictation yet the judge scored it 0.975 and praised it for
# "faithfully reproducing the dictation." This module computes an objective
# word-level novelty ratio and applies a hard cap so near-copies can never
# score high regardless of what the LLM says.
#
# Tunable: NOVELTY_CAP_THRESHOLD is the novelty below which the cap engages.
# At 0.25, a chapter must re-express at least a quarter of its words to escape
# the cap. Genuine evolutions (ch17 measured 0.67) are untouched; ch38 at
# 0.04 would have its score multiplied by ~0.16.

NOVELTY_CAP_THRESHOLD = 0.25


def _tokens(text: str) -> list[str]:
    """Normalize to lowercase word tokens, stripping markdown and punctuation."""
    import re

    cleaned = re.sub(r"[#*>_`]", "", text).lower()
    return [w for w in re.split(r"\s+", cleaned) if w]


def novelty_ratio(candidate: str, dictation: str | None) -> float | None:
    """Return 1.0 - word-level SequenceMatcher similarity.

    ``None`` if the dictation is unavailable or either side is empty (in which
    case the cap is deliberately NOT applied — we cannot prove a copy without
    the source). At 0.0 the candidate is identical to the dictation; at 1.0 it
    shares no words in the same order.
    """
    import difflib

    if not dictation or not dictation.strip():
        return None
    a = _tokens(dictation)
    b = _tokens(candidate)
    if not a or not b:
        return None
    return round(1.0 - difflib.SequenceMatcher(None, a, b, autojunk=False).ratio(), 4)


def apply_near_copy_cap(raw_score: float, novelty: float | None) -> float:
    """Progressively cap the score when novelty is below the threshold.

    At ``novelty == threshold`` the candidate keeps its full score. Below the
    threshold the kept fraction shrinks linearly to 0 at novelty 0. This is
    gentle at the boundary (0.20 novelty -> keep 80%) and crushes true
    near-copies (0.04 novelty -> keep 16%).
    """
    if novelty is None:
        return raw_score
    if novelty >= NOVELTY_CAP_THRESHOLD:
        return raw_score
    kept = max(0.0, novelty / NOVELTY_CAP_THRESHOLD)
    return round(raw_score * kept, 4)


# ── Main ─────────────────────────────────────────────────────────────────


def main() -> None:
    program_path = sys.argv[1] if len(sys.argv) > 1 else None
    output_path = sys.argv[2] if len(sys.argv) > 2 else None

    if not program_path or not output_path:
        print(json.dumps({"score": 0.0, "success": False, "error": "missing_args"}))
        sys.exit(0)

    script_dir = Path(__file__).resolve().parent

    # Read the candidate evolved chapter
    try:
        with open(program_path) as f:
            candidate = f.read()
    except Exception as e:
        result = {"score": 0.0, "success": False, "error": f"cannot_read_program: {e}"}
        with open(output_path, "w") as f:
            json.dump(result, f)
        sys.exit(0)

    if not candidate.strip():
        result = {"score": 0.0, "success": False, "error": "empty_candidate"}
        with open(output_path, "w") as f:
            json.dump(result, f)
        sys.exit(0)

    # Which chapter are we judging?
    try:
        chapter_n = int(os.environ.get("BOOK_EVOLUTION_CHAPTER_N", "1"))
    except ValueError:
        chapter_n = 1

    # Load style samples and dictation for comparison
    style_samples = load_style_samples(script_dir)
    dictation = load_dictation(script_dir)

    # Build and send evaluation prompt
    prompt = build_eval_prompt(
        candidate, style_samples, dictation, chapter_n=chapter_n
    )

    # Judge robustness: retry on refusal/unparseable body.
    t_start = time.time()
    parsed: dict[str, Any] | None = None
    last_error = "llm_call_failed"
    last_raw = ""
    for attempt in range(1, JUDGE_ATTEMPTS + 1):
        response = call_llm(prompt, max_tokens=8192)
        if not response:
            last_error = "llm_call_failed"
        else:
            candidate_parsed = parse_judge_response(response)
            if "error" not in candidate_parsed:
                parsed = candidate_parsed
                break
            last_error = candidate_parsed["error"]
            last_raw = candidate_parsed.get("raw", "")[:200]
        if attempt < JUDGE_ATTEMPTS:
            print(
                f"  Judge attempt {attempt}/{JUDGE_ATTEMPTS} failed "
                f"({last_error}); retrying...",
                file=sys.stderr,
            )
            time.sleep(JUDGE_RETRY_BACKOFF_S * attempt)
    elapsed = time.time() - t_start

    if parsed is None:
        result = {
            "score": 0.0,
            "success": False,
            "judge_failed": True,
            "error": last_error,
            "raw_response": last_raw,
            "attempts": JUDGE_ATTEMPTS,
        }
        with open(output_path, "w") as f:
            json.dump(result, f)
        print(
            f"  Judge unavailable after {JUDGE_ATTEMPTS} attempts ({last_error}) "
            f"— marked judge_failed (not a real 0.0)",
            file=sys.stderr,
        )
        sys.exit(0)

    score = compute_score(parsed)

    # ── Near-copy hard cap (deterministic backstop) ──────────────────────
    # The LLM judge cannot reliably detect verbatim copies of the dictation.
    # Compute an objective word-level novelty ratio and progressively cap the
    # score when the candidate is too close to its source. See the docstring
    # on ``apply_near_copy_cap`` for the rationale and the ch38 incident.
    raw_llm_score = score
    nov = novelty_ratio(candidate, dictation)
    capped = False
    if nov is not None and nov < NOVELTY_CAP_THRESHOLD:
        score = apply_near_copy_cap(score, nov)
        capped = True

    result = {
        "score": score,
        "success": True,
        "axes": parsed,
        "eval_score": score,
        "combined_score": score,
        "raw_llm_score": raw_llm_score,
        "novelty_ratio": nov,
        "near_copy_capped": capped,
        "novelty_cap_threshold": NOVELTY_CAP_THRESHOLD,
        "elapsed_ms": int(elapsed * 1000),
        "style_samples_available": style_samples is not None and len(style_samples) > 0,
        "dictation_available": dictation is not None,
        "chapter_n": chapter_n,
    }

    with open(output_path, "w") as f:
        json.dump(result, f, indent=2)

    if capped:
        # Same stream as the uncapped line so log scrapers see one format.
        print(
            f"  Judge score: {score:.4f} ({elapsed:.1f}s) "
            f"[NEAR-COPY CAP engaged: raw {raw_llm_score:.4f} x "
            f"novelty {nov:.3f}/{NOVELTY_CAP_THRESHOLD}]"
        )
    else:
        print(f"  Judge score: {score:.4f} ({elapsed:.1f}s)")
    print(
        f"  Novelty: {nov if nov is not None else '?'}, "
        f"Content Fidelity: {parsed.get('content_fidelity', '?')}, "
        f"Style Match: {parsed.get('author_style_match', '?')}"
    )


if __name__ == "__main__":
    main()
