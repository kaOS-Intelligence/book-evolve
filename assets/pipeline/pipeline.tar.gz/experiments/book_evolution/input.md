# Book Evolution — Chapter 1

Evolve the dictated transcript of Chapter 1 into a polished, publishable book chapter
in the author's own voice.

## Task

You are transforming raw dictated speech into finished book prose. The dictation
transcript is your content anchor — preserve every scene, character, event, and
narrative beat exactly. The author's reference book samples are your style anchor —
adopt their vocabulary, sentence architecture, pacing, dialogue handling, and tonal
register so completely that the evolved chapter reads as though the author themselves
wrote it from a clean draft.

## Content Rules

1. FIDELITY: Every factual claim, scene detail, character moment, and narrative beat
   must be traceable to the dictation transcript. No invention, no omission.
2. STYLE: The prose must match the author's voice as demonstrated in the reference
   samples provided in the cognition store.
3. COMPLETENESS: The full chapter, from first word to last. No truncation.
4. POLISH: Final-draft quality — varied sentence length, sharp imagery, natural
   transitions, rhythm that carries the reader forward.

## Reference Materials

The cognition store provides:
- The full dictation transcript for this chapter (topic: "dictation_transcript")
- The author's published book samples (topic: "author_style_sample", source: book title)

Retrieve these before beginning.
