#!/usr/bin/env python3
"""Provision a per-chapter book-evolution experiment directory.

Pattern: identical to prepare_book.py for Odyssey, but provisions chapters
(1..N) rather than books.

Each chapter gets its own isolated experiment dir (``book_evolution_chapter_NN``)
so its evolution state never collides with another chapter's.

Shared, chapter-agnostic assets are SYMLINKED back to the canonical
``book_evolution`` template:
  * ``cognition_data``  — one dictation + reference store holds all chapters
  * ``evaluator.py``, ``eval.sh`` — read the chapter from BOOK_EVOLUTION_CHAPTER_N at runtime

Chapter-specific, evolvable assets are COPIED:
  * ``prompts/``  — the researcher prompt mutates per experiment
  * ``config.yaml`` — experiment_name + system prompt rewritten for the chapter
  * ``input.md``  — task statement rewritten for the chapter

Usage:
  python3 prepare_chapter.py --chapter 1
  python3 prepare_chapter.py --chapter 2 --force
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
from pathlib import Path

EXPERIMENTS_DIR = Path(__file__).resolve().parent
TEMPLATE_NAME = "book_evolution"

ALL_SYMLINKS = [
    "cognition_data",
    "evaluator.py",
    "eval.sh",
]
COPY_TREES = ["prompts"]
COPY_FILES = ["config.yaml", "input.md"]


def _relink(link_path: Path, target_rel: str, *, force: bool) -> None:
    if link_path.is_symlink():
        if link_path.readlink() == Path(target_rel) and not force:
            return
        link_path.unlink()
    elif link_path.exists():
        if not force:
            print(f"  skip symlink (real path exists): {link_path.name}")
            return
        if link_path.is_dir():
            shutil.rmtree(link_path)
        else:
            link_path.unlink()
    link_path.symlink_to(target_rel)
    print(f"  symlink {link_path.name} -> {target_rel}")


def _rewrite_config(text: str, *, exp_name: str, chapter_n: int) -> str:
    text = re.sub(
        r"^experiment_name:.*$",
        f"experiment_name: {exp_name}",
        text,
        count=1,
        flags=re.M,
    )
    text = re.sub(r"Chapter\s+1\b", f"Chapter {chapter_n}", text)
    return text


def _rewrite_input(text: str, *, chapter_n: int) -> str:
    text = re.sub(r"Chapter\s+1\b", f"Chapter {chapter_n}", text)
    text = re.sub(
        r"Focus on Chapter.*$",
        (
            f"Focus on Chapter {chapter_n} only. Evolve the full dictation "
            "transcript for this chapter as given in the cognition store."
        ),
        text,
        flags=re.S,
    )
    return text


def prepare(chapter_n: int, *, force: bool) -> Path:
    template = EXPERIMENTS_DIR / TEMPLATE_NAME
    if not template.is_dir():
        raise SystemExit(f"Template not found: {template}")

    nn = f"{chapter_n:02d}"
    exp_name = f"book_evolution_chapter_{nn}"
    dst = EXPERIMENTS_DIR / exp_name
    dst.mkdir(parents=True, exist_ok=True)
    print(f"Preparing {exp_name} (chapter {chapter_n}) from {TEMPLATE_NAME}")

    for name in ALL_SYMLINKS:
        src = template / name
        if not src.exists():
            print(f"  (template missing {name}; skipped)")
            continue
        _relink(dst / name, f"../{TEMPLATE_NAME}/{name}", force=force)

    for tree in COPY_TREES:
        src = template / tree
        if not src.is_dir():
            continue
        dst_tree = dst / tree
        if dst_tree.exists() and force:
            shutil.rmtree(dst_tree)
        if not dst_tree.exists():
            shutil.copytree(src, dst_tree)
            print(f"  copied {tree}/")
        else:
            print(f"  kept existing {tree}/ (use --force to refresh)")

    for fname in COPY_FILES:
        src = template / fname
        if not src.is_file():
            continue
        dst_file = dst / fname
        if dst_file.exists() and not force:
            print(f"  kept existing {fname} (use --force to refresh)")
            continue
        text = src.read_text(encoding="utf-8")
        if fname == "config.yaml":
            text = _rewrite_config(text, exp_name=exp_name, chapter_n=chapter_n)
        elif fname == "input.md":
            text = _rewrite_input(text, chapter_n=chapter_n)
        dst_file.write_text(text, encoding="utf-8")
        print(f"  wrote {fname} (chapter {chapter_n})")

    print(f"Ready: {dst}")
    return dst


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Provision a per-chapter book-evolution experiment dir"
    )
    parser.add_argument(
        "--chapter", type=int, required=True, help="Chapter number (1..N)"
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Refresh symlinks/copies even if the dir already exists",
    )
    args = parser.parse_args()
    if args.chapter < 1:
        raise SystemExit("--chapter must be >= 1")
    prepare(args.chapter, force=args.force)
    return 0


if __name__ == "__main__":
    sys.exit(main())
