#!/bin/bash
# Seed the shared cognition store for a specific chapter before evolution.
#
# Generalized: no book-specific paths. Chapter N maps to the Nth .txt file
# (1-based, sorted by name) in the dictation directory. Every .txt file in
# the reference directory becomes an author style sample.
#
# NOTE: run_book_evolution_service.py --dictation-dir/--reference-dir does
# this automatically per chapter. Use this script only for manual single-
# chapter seeding.
#
# Usage:
#   ./seed_chapter_cognition.sh <chapter_number> <dictation_dir> [reference_dir]

set -euo pipefail

CHAPTER_N=${1:?Usage: $0 <chapter_number> <dictation_dir> [reference_dir]}
DICTATION_DIR=${2:?Usage: $0 <chapter_number> <dictation_dir> [reference_dir]}
REFERENCE_DIR=${3:-}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EVOLVE_ROOT="$(dirname "$SCRIPT_DIR")"
COG_DIR="$SCRIPT_DIR/book_evolution/cognition_data"

# Resolve the Nth dictation file (1-based, sorted by name).
# (sed -n Np keeps this compatible with macOS bash 3.2 — no mapfile.)
TOTAL=$(find "$DICTATION_DIR" -maxdepth 1 -name '*.txt' -type f | wc -l | tr -d ' ')
if [ "$CHAPTER_N" -gt "$TOTAL" ] || [ "$CHAPTER_N" -lt 1 ]; then
  echo "Chapter $CHAPTER_N out of range: $TOTAL dictation files in $DICTATION_DIR" >&2
  exit 1
fi
DICT_FILE=$(find "$DICTATION_DIR" -maxdepth 1 -name '*.txt' -type f | sort | sed -n "${CHAPTER_N}p")

PYTHON="$EVOLVE_ROOT/.venv/bin/python3"
[ -x "$PYTHON" ] || PYTHON="python3"

ARGS=(--dictation "$DICT_FILE" --output-dir "$COG_DIR")
if [ -n "$REFERENCE_DIR" ] && [ -d "$REFERENCE_DIR" ]; then
  while IFS= read -r ref; do
    title="$(basename "$ref" .txt | tr '-' ' ')"
    ARGS+=(--reference "$ref" "$title")
  done < <(find "$REFERENCE_DIR" -maxdepth 1 -name '*.txt' -type f | sort)
fi

echo "Seeding cognition for chapter $CHAPTER_N ($(basename "$DICT_FILE"))..."
"$PYTHON" "$SCRIPT_DIR/seed_book_evolution_cognition.py" "${ARGS[@]}"
echo "Done seeding chapter $CHAPTER_N"
